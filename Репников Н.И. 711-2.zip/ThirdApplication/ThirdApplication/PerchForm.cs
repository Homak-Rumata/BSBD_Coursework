﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThirdApplication
{
    public partial class PerchForm : Form
    {
        public delegate void WritePerch(double one, double two, double tree, double four);

        

        public PerchForm(WritePerch WritePerch)
        {
            _writePerch = WritePerch;
            InitializeComponent();
        }

        public void Open()
        {
            Show();
        }

        private void ConfirmButton_Click(object sender, EventArgs e)
        {

            try
            {
                _writePerch(Convert.ToDouble(textBox1.Text),
                    Convert.ToDouble(textBox2.Text),
                    Convert.ToDouble(textBox3.Text),
                    Convert.ToDouble(textBox4.Text));
                this.Close();
            }
            catch
            {
                MessageBox.Show(" Неверно введены данные ", " Ошибка в данных ");
            }
        }

        WritePerch _writePerch;
    }
}
