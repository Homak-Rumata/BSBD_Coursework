﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThirdApplication.Interfaces;

namespace ThirdApplication
{
    public partial class AutorizationForm : Form, IWorkForm
    {
        public AutorizationForm(ParrentFormAction FormOpen)
        {
            InitializeComponent();
            _parrentOpen = FormOpen;
            //Open();
        }


        public void Open()
        {
            Show();
        }

        


        private ParrentFormAction _parrentOpen; 

        private void InputButton_Click(object sender, EventArgs e)
        {
            //Здесь мы получаем открываемую форму
            

            IConnection connection = new Connection(NameTextBox.Text, PasswordTextBox.Text);
            IWorkForm WorkForm = connection.GetState();
            if (!(WorkForm is null))
            {
                _parrentOpen(this, WorkForm);
            }

        }
    }
}
