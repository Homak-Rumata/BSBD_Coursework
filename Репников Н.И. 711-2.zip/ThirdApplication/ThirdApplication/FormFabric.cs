﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThirdApplication.Interfaces;

namespace ThirdApplication
{
    static class FormFabric
    {
        static public IWorkForm GetForm(string Name, string Password)
        {
            IConnection connection = new Connection(Name, Password);
            return connection.GetState();
        }
    }
}
