﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThirdApplication
{
    public partial class RevisorForm : Form
    {
        Connection.RevisorORM ORM;

        public RevisorForm(Connection.RevisorORM RevORM)
        {
            ORM = RevORM;
            InitializeComponent();
            Fill();
        }


        public void Open()
        {
            Show();
        }

        void Fill ()
        {
            string[,] First;
            string[,] Second;
            string[,] Third;
            (First, Second, Third) = ORM.GetDate();

            dataGridView4.Rows.Clear();
            dataGridView4.AllowUserToAddRows = false;

            for (int i = 0; i < First.GetLength(0); i++)
            {
                try
                {
                    dataGridView4.Rows.Add(First[i,3], First[i,4]);

                }
                catch { }
            }

            PerchTabble.Rows.Clear();
            PerchTabble.AllowUserToAddRows = false;

            for (int i = 0; i < Second.GetLength(0); i++)
            {
                try
                {
                    PerchTabble.Rows.Add(Second[i,0], Second[i, 3], Second[i, 4]);

                }
                catch { }
            }

            dataGridView5.Rows.Clear();
            dataGridView5.AllowUserToAddRows = false;

            for (int i = 0; i < Third.GetLength(0); i++)
            {
                try
                {
                    dataGridView5.Rows.Add(Third[i, 2], Third[i, 1]);

                }
                catch { }
            }
        }
    }
}
