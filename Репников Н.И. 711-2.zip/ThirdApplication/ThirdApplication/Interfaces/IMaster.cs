﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThirdApplication
{
    internal interface IMaster
    {
        void Add((int, string)[] order);

        ((int, string)[], (int, int)[]) Viem();


    }
}
