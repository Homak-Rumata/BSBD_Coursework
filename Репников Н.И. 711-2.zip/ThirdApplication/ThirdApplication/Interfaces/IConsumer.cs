﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThirdApplication
{
    internal interface IConsumer
    {
        void Add((int, string)[] order);

        (int, string)[] Viem();

        (int, string) Viem(int number);

    }
}
