﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThirdApplication.Interfaces
{
    public delegate void ParrentFormAction(AutorizationForm autorizationForm, IWorkForm OpenForm);
    public delegate void FormHandler(IWorkForm e);

    public interface IWorkForm
    {
        void Open();
        void Close();

        event EventHandler Closed;

        
    }

    interface IMasterForm: IWorkForm
    {

    }

    interface IRevisorForm: IWorkForm
    {

    }

    interface IConsumerForm: IWorkForm
    {

    }
}
