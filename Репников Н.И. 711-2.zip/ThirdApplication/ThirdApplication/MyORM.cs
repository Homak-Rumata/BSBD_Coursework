﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThirdApplication.Interfaces;

namespace ThirdApplication
{
    interface IConnection
    {
        IWorkForm GetState();
    }

    delegate void Connector(SqlConnection connection);

    public enum State
    {
        Default,
        Revisor,
        Consumer,
        Master
    }

    public abstract class CreateConnection
    {
        SqlConnection connection;
        public State _state;

        protected SqlCommand ConnectCommand
        {
            set
            {
                value.Connection = connection;
            }
        }

        public CreateConnection(string Name, string Password) { 
            string connectionstring = $"Server=LAPTOP-OJ1V4VI9;Database=FirstDB;User Id={Name};Password={Password};";
            try
            {
                SqlConnection connect = new SqlConnection(connectionstring);
                connection = connect;
                connection.Open();                

                Console.WriteLine("Свойства подключения:");
                Console.WriteLine($"\tСтрока подключения: {connection.ConnectionString}");
                Console.WriteLine($"\tБаза данных: {connection.Database}");
                Console.WriteLine($"\tСервер: {connection.DataSource}");
                Console.WriteLine($"\tВерсия сервера: {connection.ServerVersion}");
                Console.WriteLine($"\tСостояние: {connection.State}");
                Console.WriteLine($"\tWorkstationld: {connection.WorkstationId}");


                SqlCommand A = new SqlCommand("SELECT USER_NAME()", connection);
                SqlDataReader reader = A.ExecuteReader();
                reader.Read();
                switch (Convert.ToString(reader.GetValue(0)))
                {
                    case "Revisorka": _state=State.Revisor; break;
                    case "MasterRoleka": _state = State.Master; break;
                    case "Buyerka": _state=State.Consumer; break;
                }

                reader.Close();

               

            }
            catch
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    Console.WriteLine("Подключение закрыто...");
                }
                MessageBox.Show("Неудачное подключение к базе данных");
            }
            finally
            {
            }
        }

        ~CreateConnection() {
            try
            {
                connection.Close();
            }
            catch { }
        }
    }

    public class Connection: CreateConnection, IConnection 
    {
        
        public Connection(string Name, string Password)
            :base (Name, Password)
        {
            command = new SqlCommand();
            base.ConnectCommand = command;

 

        }
        

        SqlCommand command;

        public IWorkForm  GetState ()
        {
            switch (base._state)
            {
                case State.Revisor:
                    return new RevisorForm(new RevisorORM(ref command));
                case State.Consumer:
                    return new ConsumerForm(new ConsumerORM(ref command));
                case State.Master:
                    return new MasterForm();
                    //Написать форму неавторизации
                default: return null;
            }
            
        }


        public class RevisorORM
        {
            SqlCommand command;
            public RevisorORM (ref SqlCommand command)
            {
                this.command = command;
            }

            public (string[,], string[,], string[,]) GetDate ()
            {
                string FirstCommand = "Select [Нижний склад].[Номер склада],  " +
                    "[Нижний склад].[Дата], [Нижний склад].[Номер бригады], " +
                    "[Партия ассортимента].[Тип сортимента], [Партия ассортимента].[Число сортиментов]" +
                    "\r\n\r\nFROM [Нижний склад]\r\n\r\nJOIN [Партия ассортимента] " +
                    "ON [Партия ассортимента].[Номер партии]=[Нижний склад].[№ партии сортимента]";

                string SecondCommand = "Select [Заказы].[Номер заказа], " +
                    "[Заказы].Статус, [Заказы].Сумма, [Кодификатор заказа].Кубатура, " +
                    "[Кодификатор заказа].[Тип материала]\r\n\r\nFROM Заказы\r\n\r\nJOIN " +
                    "[Кодификатор заказа] ON [Заказы].[Номер заказа]=[Кодификатор заказа].[Номер заказа]";

                string ThirdCommand = "SELECT [Партия пиломатериала].[Номер партии], [Партия пиломатериала].Кубатура, [Партия пиломатериала].[Тип материала], [Кодификатор Партий].Дата, [Кодификатор Партий].[Название предприятия]\r\nFROM [Партия пиломатериала]\r\nJOIN [Кодификатор Партий] on [Партия пиломатериала].[Номер партии]=[Кодификатор Партий].[№ партии пиломатериала]";

                string[,] ReadText (SqlCommand command, string CommandText)
                {
                    command.CommandText = CommandText;
                    List<string[]> temp = new List<string[]>();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string[] tempest = new string[5];
                        object[] A = new object[tempest.Length]; 
                        reader.GetValues(A);
                        for (int i = 0; i < tempest.Length; i++)
                        {
                            tempest[i] = Convert.ToString(A[i]);
                        }
                        temp.Add(tempest);
                    }

                    reader.Close();

                    string[,] tempestus = new string[temp.LongCount(), 5];

                    for (int i = 0; i<temp.LongCount(); i++)
                    {
                        for (int j = 0; j<5; j++)
                        {
                            tempestus[i, j] = temp[i][j];
                        }
                    }

                    return tempestus;
                }

                return (ReadText(command, FirstCommand), ReadText(command, SecondCommand), ReadText(command, ThirdCommand));

            }

        }

        public class ConsumerORM
        {
            SqlCommand _command;
            public ConsumerORM(ref SqlCommand command)
            {
                _command = command;
            }

            public void AddDate(double desk, double fatdesk, double lafet, double quadrolog)
            {
                string commandText = "INSERT INTO [Заказы] \r\nValues \r\n" +
                    $"('Не выполнен', {desk*10+fatdesk*20+lafet*40+quadrolog*60}) " +

                    "INSERT INTO [Кодификатор заказа]\r\nVALUES\r\n" +
                    "((SELECT MAX([Заказы].[Номер заказа]) FROM [Заказы]), " +
                    $"'тёс',{desk})" +

                    "INSERT INTO [Кодификатор заказа]\r\nVALUES\r\n" +
                    "((SELECT MAX([Заказы].[Номер заказа]) FROM [Заказы]), " +
                    $"'плаха',{fatdesk})" +

                    "INSERT INTO [Кодификатор заказа]\r\nVALUES\r\n" +
                    "((SELECT MAX([Заказы].[Номер заказа]) FROM [Заказы]), " +
                    $"'лафет',{lafet})" +

                    "INSERT INTO [Кодификатор заказа]\r\nVALUES\r\n" +
                    "((SELECT MAX([Заказы].[Номер заказа]) FROM [Заказы]), " +
                    $"'брус',{quadrolog})";

                    _command.CommandText = commandText;
                    List<string[]> temp = new List<string[]>();
                    _command.ExecuteNonQuery();
            }

            public string[,] UpdateDate ()
            {
                string CommandText = "SELECT [Кодификатор заказа].[Тип материала], " +
                    "[Кодификатор заказа].Кубатура\r\nFROM [Кодификатор заказа]\r\n" +
                    "JOIN [Заказы] ON [Кодификатор заказа].[Номер заказа]=[Заказы].[Номер заказа]";

                _command.CommandText = CommandText;
                List<string[]> temp = new List<string[]>();
                SqlDataReader reader = _command.ExecuteReader();
                while (reader.Read())
                {
                    string[] tempest = new string[2];
                    object[] A = new object[tempest.Length];
                    reader.GetValues(A);
                    for (int i = 0; i < tempest.Length; i++)
                    {
                        tempest[i] = Convert.ToString(A[i]);
                    }
                    temp.Add(tempest);
                }

                reader.Close();

                string[,] tempestus = new string[temp.LongCount(), 5];

                for (int i = 0; i < temp.LongCount(); i++)
                {
                    for (int j = 0; j < 2; j++)
                    {
                        tempestus[i, j] = temp[i][j];
                    }
                }

                return tempestus;

            }
        }

        public class MasterORM
        {
            SqlCommand command;

            public MasterORM(ref SqlCommand command)
            {
                this.command = command;
            }

            public void Update ()
            {

            }
            

            public (string[,], string[,]) GetDate ()
            {
                return (null, null);
            }
        }


    }

    /*class MyORMFabric : Connection
    {
        public MyORMFabric(string Name, string Password) : base(Name, Password)
        {

        }



    }*/
}
