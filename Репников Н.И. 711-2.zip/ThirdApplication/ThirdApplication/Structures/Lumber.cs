﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThirdApplication.Structures
{
    struct Lumber
    {
        public (string Category, int count)[] Value;

        public static Lumber operator + (Lumber left, Lumber right)
        {
            Lumber ended = new Lumber();

            ended.Value = new (string, int)[left.Value.Length+right.Value.Length];

            for (int i = 0; i < left.Value.Length; i++ )
            {
                ended.Value[i] = left.Value[i];
            }

            for (int i = 0; i < right.Value.Length; i++)
            {
                ended.Value[i+left.Value.Length] = right.Value[i];
            }

            return ended;
        }
    }
}
