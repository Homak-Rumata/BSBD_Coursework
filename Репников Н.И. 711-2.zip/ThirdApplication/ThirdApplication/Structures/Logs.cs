﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdApplication.Interfaces;

namespace ThirdApplication.Structures
{
    struct Logs
    {
        Logs ((int, int)[] logs)
        {
            _logs = logs;
        }

        private (int, int)[] _logs;

        public (int, int)[] logs
        {
            get { return _logs; }
        }

        public static Logs operator + (Logs left, Logs right)
        {
            return new Logs(left.logs.Concat(right.logs).ToArray());
        }


    }
}
