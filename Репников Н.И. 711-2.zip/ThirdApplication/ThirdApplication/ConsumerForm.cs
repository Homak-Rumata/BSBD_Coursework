﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThirdApplication.Interfaces
{
    public partial class ConsumerForm : Form, IWorkForm
    {

        Connection.ConsumerORM ORM;

        public ConsumerForm(Connection.ConsumerORM _ORM)
        {
            InitializeComponent();
            ORM = _ORM;
            UpdateTabble();
        }


        public void Open()
        {
            Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PerchForm Perch = new PerchForm(WritePerch);
            Perch.Show();
        }

        private void WritePerch (double desk, double fatdesk, double lafet, double quadrolog)
        {
            ORM.AddDate(desk, fatdesk, lafet, quadrolog);  


            UpdateTabble();
        }

        //List<(double, double, double, double)> a = new List<(double, double, double, double)>();

        private void UpdateTabble ()
        {
            DataBase.Rows.Clear();
            DataBase.AllowUserToAddRows = false;

            string[,]Date = ORM.UpdateDate();

            for (int i = 0; i < Date.GetLength(0); i++)
            {
                try
                {
                    DataBase.Rows.Add(Date[i, 0], Date[i, 1]);

                }
                catch { }
            }


            

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }




}
