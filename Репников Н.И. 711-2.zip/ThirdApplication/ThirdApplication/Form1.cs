﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThirdApplication.Interfaces;

namespace ThirdApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            AutorizationForm autorizationForm = new AutorizationForm(OpenAutorizationForm);
            autorizationForm.ShowDialog();
            Console.WriteLine("NOT HIDE");
            HideForm(this);
        }

        private void HideForm (Form1 form)
        {
            Console.WriteLine("Hided");
            form.Visible = false;
            form.Hide();
        }

        void OpenAutorizationForm (AutorizationForm autorizationForm, IWorkForm Form)
        {
            //Form.Open ();
            Form.Closed += Form_Closed;
            HideForm(this);
            autorizationForm.Close ();
            _nextForm = Form as Form;
            
        }

        private Form _nextForm;

        public Form GetForm
        {
            get
            {
                return _nextForm;
            }
        }

        private void Form_Closed(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HideForm(this);
        }
    }
}
